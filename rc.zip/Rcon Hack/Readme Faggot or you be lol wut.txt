put the rcon_adv_dupe_exploit.lua in 
C:\Program Files (x86)\Steam\steamapps\STEAMNAME\garrysmod\garrysmod\lua\autorun\client

Put hax.txt in adv dupe folder.

How to use:

1:Go to server.
2:Must allow adv dupe.
3:Upload Hax.txt
4:Spawn Hax.txt (its a chair)
5:Sit in the chair.
6:In console type one of these commands.

Commands:

After above is done you can use these.

exploit_admin ( Makes everyone Owner or superadmin. Not permanently though :/)
exploit_bans (makes everyone unkickable or unbanable, except by rcon :/)
exploit_cfg (shows the cfg file for the server. it shows the rcon pass in there :D)
exploit_rcon (hacks rcon without password type in console lol_rcon to use rcon after this command. eg: lol_rcon adduser ulx name superadmin 1)